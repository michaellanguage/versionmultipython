version="2.0"
class Foo():
    def getData(self):
        return b"Foo"
