
import os,sys
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.append(os.path.dirname(os.path.realpath(os.path.join(SCRIPT_DIR, "../"))))
from a import __required_modules_path

sys.path.insert(0,__required_modules_path.get("foo"))
from foo import Foo


a = Foo()
print(a.getData().lower())