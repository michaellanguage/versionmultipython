import os
import re

__package_path = os.path.dirname(__file__)
__requirement_file = os.path.join(__package_path, "requirements.txt")

__required_modules_path = {}

# dummy passer of requirements
with open(__requirement_file, 'r') as f:
    depen_resolve =list( filter(len, re.split(r'(\r\n|\n)', f.read())))
    depen_resolve =list( filter(lambda x : not x == "\n" or x == "\r",  depen_resolve))
    for depenency in depen_resolve:
        ver_resolve =list( filter(len, re.split(r'[\>\=\<]', depenency)))
        package, version = ver_resolve
        __required_modules_path[package]=os.path.join(__package_path, package, os.sep.join(version.split(".")))



