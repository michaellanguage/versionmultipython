
version="1.0"
class Foo():
    def getData(self):
        return "FOO"
