
from importlib import import_module
imp = import_module("foo.1.0.foo")
classname = "Foo"
Foo = getattr(imp, classname)



a = Foo()
print(a.getData().lower())