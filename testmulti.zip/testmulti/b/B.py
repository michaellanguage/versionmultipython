import sys
from . import __required_modules_path

sys.path.insert(0,__required_modules_path.get("foo"))
from foo import Foo
class B():

    def get_foo_object(self):
        return Foo()
