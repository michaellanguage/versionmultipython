from b.B import B
from a.A import A

b_v = B()
a_v = A()


print(a_v.get_foo_object().getData())
print(b_v.get_foo_object().getData())