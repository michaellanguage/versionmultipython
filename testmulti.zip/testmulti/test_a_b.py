from a.A import A
from b.B import B

a_v = A()
b_v = B()

print(a_v.get_foo_object().getData())
print(b_v.get_foo_object().getData())