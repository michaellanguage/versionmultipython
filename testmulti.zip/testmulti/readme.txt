Foo 2.0 version getData returns Bytes
Foo 1.0 version getData returns String